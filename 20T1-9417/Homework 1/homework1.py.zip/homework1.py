import matplotlib.pyplot as plt
import pandas as pd
import numpy as np

df = pd.read_csv('house_prices.csv')
df['number of convenience stores'] = df['number of convenience stores'].astype(float)

# 1. Pre-processing
def normalisation(df):
    columns = df.columns
    for column in columns[1:-1]:
        min_x = df.loc[:,column].min()
        max_x = df.loc[:,column].max()
        for i in range(len(df)):
            x = df.at[i,column]
            df.at[i,column] = round((x - min_x) / (max_x - min_x),2)
normalisation(df)

# 2. Creating test and training set
df_train = df[:301]
df_test = df[301:]

x = 'house age'
y = 'house price of unit area'

x_train = df_train[x].to_numpy()
y_train = df_train[y].to_numpy()

x_test = df_test[x].to_numpy()
y_test = df_test[y].to_numpy()

# 3. Stochastic gradient descent
theta_0 = -1
theta_1 = -0.5
iteration = 50
alpha = 0.01
loss = []

for i in range(iteration):
    error_0 = []
    error_1 = []
    for j in range(len(df_train)):
        predict_data = theta_0 + theta_1 * x_train[j]
        e = y_train[j]-predict_data
        error_0.append(e)
        error_1.append(e*x_train)
    theta_0 = theta_0 + alpha * (np.mean(error_0))
    theta_1 = theta_1 + alpha * (np.mean(error_1))
    loss.append([np.mean(error_0)**2])
    
print('Theta 0 is: {}'.format(theta_0))
print('Theta 1 is: {}'.format(theta_1))

# 4. Visualization
plt.plot(loss)
plt.show()

# 5. Evaluation RMSE
train_rmse = []

for i in range(len(df_train)):
    predict = theta_0 + theta_1 * x_train[i]
    tmp = (y_train[i] - predict) ** 2
    train_rmse.append(tmp)
print('The rmse of the training data set is: {}'.format(np.sqrt(np.mean(train_rmse))))

test_rmse = []

for j in range(len(df_test)):
    predict = theta_0 + theta_1 * x_test[j]
    tmp = (y_test[j] - predict) ** 2
    test_rmse.append(tmp)
print('The rmse of the test data set is: {}'.format(np.sqrt(np.mean(test_rmse))))